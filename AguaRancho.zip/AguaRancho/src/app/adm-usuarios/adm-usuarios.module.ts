import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdmUsuariosPageRoutingModule } from './adm-usuarios-routing.module';

import { AdmUsuariosPage } from './adm-usuarios.page';
import { EncabezadoAdmComponent } from '../encabezado-adm/encabezado-adm.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule, ReactiveFormsModule,
    IonicModule,
    AdmUsuariosPageRoutingModule
  ],
  declarations: [AdmUsuariosPage,EncabezadoAdmComponent]
})
export class AdmUsuariosPageModule {}
