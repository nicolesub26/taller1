import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)
  },
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'login',
    loadChildren: () => import('./login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'administrador',
    loadChildren: () => import('./administrador/administrador.module').then( m => m.AdministradorPageModule)
  },
  {
    path: 'adm-socios',
    loadChildren: () => import('./adm-socios/adm-socios.module').then( m => m.AdmSociosPageModule)
  },
  {
    path: 'add-socios',
    loadChildren: () => import('./add-socios/add-socios.module').then( m => m.AddSociosPageModule)
  },
  {
    path: 'adm-roles',
    loadChildren: () => import('./adm-roles/adm-roles.module').then( m => m.AdmRolesPageModule)
  },
  {
    path: 'add-roles',
    loadChildren: () => import('./add-roles/add-roles.module').then( m => m.AddRolesPageModule)
  },
  {
    path: 'adm-medidores',
    loadChildren: () => import('./adm-medidores/adm-medidores.module').then( m => m.AdmMedidoresPageModule)
  },
  {
    path: 'add-medidores',
    loadChildren: () => import('./add-medidores/add-medidores.module').then( m => m.AddMedidoresPageModule)
  },
  {
    path: 'adm-usuarios',
    loadChildren: () => import('./adm-usuarios/adm-usuarios.module').then( m => m.AdmUsuariosPageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
