import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Roles } from '../modelos/roles';
import { RolesService } from '../servicios/roles.service';

@Component({
  selector: 'app-add-roles',
  templateUrl: './add-roles.page.html',
  styleUrls: ['./add-roles.page.scss'],
})
export class AddRolesPage implements OnInit {
  new_rol = new FormGroup({
    cod : new FormControl('',[Validators.required,Validators.minLength(3)]),
    desc : new FormControl('',[Validators.required,Validators.minLength(5)]),
    activ: new FormControl()
  })

  constructor(private serv:RolesService) { }

  ngOnInit() {
    // TODO document why this method 'ngOnInit' is empty
  
  }

  Guardar() { 
    let Dato:Roles = new Roles();
    Dato.codigo=this.new_rol.value.cod;
    Dato.descripcion=this.new_rol.value.desc;
    Dato.activo=this.new_rol.value.activ;
    this.serv.add(Dato);
    }
}
