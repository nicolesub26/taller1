import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AddSociosPageRoutingModule } from './add-socios-routing.module';

import { AddSociosPage } from './add-socios.page';
import { EncabezadoAdmComponent } from '../encabezado-adm/encabezado-adm.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,ReactiveFormsModule,
    AddSociosPageRoutingModule
  ],
  declarations: [AddSociosPage,EncabezadoAdmComponent]
})
export class AddSociosPageModule {}
