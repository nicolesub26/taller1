import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AddSociosPage } from './add-socios.page';

const routes: Routes = [
  {
    path: '',
    component: AddSociosPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AddSociosPageRoutingModule {}
