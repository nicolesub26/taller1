import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-encabezado-adm',
  templateUrl: './encabezado-adm.component.html',
  styleUrls: ['./encabezado-adm.component.scss'],
})
export class EncabezadoAdmComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
