import { Component, OnInit } from '@angular/core';
import { Medidores } from '../modelos/medidores';
import { MedidoresService } from '../servicios/medidores.service';

@Component({
  selector: 'app-adm-medidores',
  templateUrl: './adm-medidores.page.html',
  styleUrls: ['./adm-medidores.page.scss'],
})
export class AdmMedidoresPage implements OnInit {
  list_medidor:any;

  constructor(private serv:MedidoresService) { }

  ngOnInit() {
    this.list_medidor=this.serv.lista();
  }

  editar(e) { console.log(e); }

  borrar(e:Medidores) { this.serv.borrar(e); this.ngOnInit(); }

}
