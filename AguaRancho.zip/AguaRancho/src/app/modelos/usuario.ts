export class Usuario {
    user: String;
    clave: String;
}