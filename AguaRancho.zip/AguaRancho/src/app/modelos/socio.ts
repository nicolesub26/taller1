export class Socio {
        id:Number;
        celular:String;
        nombres:String;
        apellidos:String;
        correo:String;
        activo:Boolean;
        foto:String;
        fechaNacimiento:Date;
        fechaRegistro:Date;
        direccion:String;
}
