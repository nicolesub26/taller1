export class Multa {
    id_Multas:number;
    FechaVigencia:Date;
    monto:number;
}
