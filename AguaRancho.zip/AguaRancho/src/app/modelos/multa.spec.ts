import { Multa } from './multa';

describe('Multa', () => {
  it('should create an instance', () => {
    expect(new Multa()).toBeTruthy();
  });
});
