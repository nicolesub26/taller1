import { Socio } from './socio';

describe('Socio', () => {
  it('should create an instance', () => {
    expect(new Socio()).toBeTruthy();
  });
});
