export class Medidores {
    id_Medidor:Number;
    serial:String;
    marca:String;
    reg_Inic:Number;
    fechaInstalacion:Date;
}
