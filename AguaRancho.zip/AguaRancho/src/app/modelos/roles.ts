export class Roles {
    id:number;
    codigo:String;
    descripcion:String;
    activo:Boolean;

    //Set<Usuario> users;
}
