import { Medidores } from './medidores';

describe('Medidores', () => {
  it('should create an instance', () => {
    expect(new Medidores()).toBeTruthy();
  });
});
