import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { UsuarioService } from '../servicios/usuario.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  datos = new FormGroup({
    user: new FormControl('',[Validators.required, Validators.minLength(5)]),
    pass: new FormControl('',[Validators.required, Validators.minLength(6)]),
  });

  constructor(private serv:UsuarioService) { }

  ngOnInit() {
  }

  public InicSes() {
    this.serv.IniciarSesion(this.datos.controls.user.value,
      this.datos.controls.pass.value); 
  }

}
