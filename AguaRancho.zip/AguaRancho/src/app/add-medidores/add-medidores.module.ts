import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AddMedidoresPageRoutingModule } from './add-medidores-routing.module';

import { AddMedidoresPage } from './add-medidores.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AddMedidoresPageRoutingModule
  ],
  declarations: [AddMedidoresPage]
})
export class AddMedidoresPageModule {}
