import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdmRolesPageRoutingModule } from './adm-roles-routing.module';

import { AdmRolesPage } from './adm-roles.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdmRolesPageRoutingModule
  ],
  declarations: [AdmRolesPage]
})
export class AdmRolesPageModule {}
