import { Component, OnInit } from '@angular/core';
import { Roles } from '../modelos/roles';
import { RolesService } from '../servicios/roles.service';

@Component({
  selector: 'app-adm-roles',
  templateUrl: './adm-roles.page.html',
  styleUrls: ['./adm-roles.page.scss'],
})
export class AdmRolesPage implements OnInit {

  list_roles:any;

  constructor(private serv:RolesService) { }

  ngOnInit() {
    this.list_roles=this.serv.lista();
  }

  borrar(e:Roles) { this.serv.borrar(e); }

}
