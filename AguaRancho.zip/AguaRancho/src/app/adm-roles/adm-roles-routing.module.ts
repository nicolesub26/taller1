import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdmRolesPage } from './adm-roles.page';

const routes: Routes = [
  {
    path: '',
    component: AdmRolesPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdmRolesPageRoutingModule {}
