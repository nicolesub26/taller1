import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Medidores } from '../modelos/medidores';
import { StoreService } from './store.service';

@Injectable({
  providedIn: 'root'
})
export class MedidoresService {
  server = "https://localhost:9090/medidores";
  
  Opciones = {
    headers: new HttpHeaders({
      'Content-Type':  'application/json'
    })
  };
  toastController: any;

  constructor(private http: HttpClient, 
    private serv:StoreService) { }

  lista():Medidores[] {
      let items:Medidores[]=[];
      this.serv.get('token').then(data => {
        this.Opciones.headers=this.Opciones.headers.
          set('Authorization','Basic '+data);
        this.http.get(this.server,this.Opciones).subscribe(
        data => { 
          let datos=data['_embedded']['medidors'];
          datos.forEach(element => {
            let T:Medidores = new Medidores();
            let id_string:string = element['_links']['self']['href'];
            T.id_Medidor=Number.parseInt(id_string.substring(id_string.lastIndexOf('/')+1));
            T.marca=element['marca'];
            T.serial=element['serial'];
            T.reg_Inic=element['reg_Inic'];
            T.fechaInstalacion=element['fechaInstalacion'];
            items.push(T);
          });
         });
      });
      return items;
    }
  
    add(T:Medidores) {
      let dat=JSON.stringify(T); 
      this.serv.get('token').then(data => {
        this.Opciones.headers=this.Opciones.headers.
          set('Authorization','Basic '+data);
          this.http.post(this.server,dat,this.Opciones).subscribe(
            async data => { const toast = await this.toastController.create({
              message: 'Guardado',
              duration: 1000,
              position: top
            });
            await toast.present();
           }, 
            async error => {
              const toast = await this.toastController.create({
                message: 'Error',
                duration: 1000,
                position: top
              });
              await toast.present();
            }
          );
    });
    }
  
    borrar(T:Medidores) {
      this.serv.get('token').then(data => {
        this.Opciones.headers=this.Opciones.headers.
          set('Authorization','Basic '+data);
        this.http.delete(this.server+'/'+T.id_Medidor.toString(),this.Opciones)
        .subscribe(data=> console.log("Borrado"),
                    error=> console.log(error))
      })
    }
  }
