import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Socio } from '../modelos/socio';
import { StoreService } from './store.service';
import { UsuarioService } from './usuario.service';

@Injectable({
  providedIn: 'root'
})
export class SociosService {
  server = "https://localhost:9090/socios";
  
  Opciones = {
    headers: new HttpHeaders({
      'Content-Type':  'application/json'
    })
  };
  constructor(private http: HttpClient, 
    private serv:StoreService) { }

  getSocios():Socio[] {
    var items:Socio[]=[];
    this.serv.get('token').then(data => {
      console.log(data);
      this.Opciones.headers=this.Opciones.headers.
        set('Authorization','Basic '+data);
      this.http.get(this.server,this.Opciones).subscribe(
      data => { 
        var datos=data['_embedded']['socios'];
        datos.forEach(element => {
          var T:Socio = new Socio();
          var id_string:String = element['_links']['self']['href'];
          T.id=Number.parseInt(id_string.substring(id_string.lastIndexOf('/')+1));
          T.apellidos=element['apellidos'];
          T.nombres=element['nombres'];
          T.celular=element['celular'];
          T.correo=element['correo'];
          T.foto="data:image/jpeg;base64,"+element['foto'];
          items.push(T);//console.log(T);
        });
       });
    });
    return items;
  }

  add(T:Socio) {
    var dat=JSON.stringify(T); 
    this.serv.get('token').then(data => {
      this.Opciones.headers=this.Opciones.headers.
        set('Authorization','Basic '+data);
        this.http.post(this.server,dat,this.Opciones).subscribe(
          data => { console.log("HECHO")},  //Aquí añadir Usuario del Socio
          error => console.log(error)
        );
  });
  }

  borrar(T:Socio) {
    this.serv.get('token').then(data => {
      this.Opciones.headers=this.Opciones.headers.
        set('Authorization','Basic '+data);
      this.http.delete(this.server+'/'+T.id.toString(),this.Opciones)
      .subscribe(data=> console.log("Borrado"),
                  error=> console.log(error))
    })
  }
}
