import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdmSociosPage } from './adm-socios.page';

const routes: Routes = [
  {
    path: '',
    component: AdmSociosPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdmSociosPageRoutingModule {}
