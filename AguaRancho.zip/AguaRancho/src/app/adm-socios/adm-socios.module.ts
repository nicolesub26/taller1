import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdmSociosPageRoutingModule } from './adm-socios-routing.module';

import { AdmSociosPage } from './adm-socios.page';
import { EncabezadoAdmComponent } from '../encabezado-adm/encabezado-adm.component';
import { UsuarioService } from '../servicios/usuario.service';
import { IonicStorageModule } from '@ionic/storage-angular';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdmSociosPageRoutingModule, IonicStorageModule.forRoot()
  ],
  declarations: [AdmSociosPage, EncabezadoAdmComponent],
  providers: [UsuarioService]
})
export class AdmSociosPageModule {}
