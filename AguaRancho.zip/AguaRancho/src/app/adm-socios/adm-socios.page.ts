import { Component, OnInit } from '@angular/core';
import { Socio } from '../modelos/socio';
import { SociosService } from '../servicios/socios.service';

@Component({
  selector: 'app-adm-socios',
  templateUrl: './adm-socios.page.html',
  styleUrls: ['./adm-socios.page.scss'],
})
export class AdmSociosPage implements OnInit {
  list_socios:any;

  constructor(private serv:SociosService) { }

  ngOnInit() {
    this.list_socios=this.serv.getSocios();
    console.log(this.list_socios);
  }

  editar(e) { console.log(e); }

  borrar(e:Socio) { this.serv.borrar(e); }
}
