package taller.BD.Server;

import org.springframework.data.repository.CrudRepository;

public interface RepoConsumos extends CrudRepository<Consumos,Integer> {
    
}
