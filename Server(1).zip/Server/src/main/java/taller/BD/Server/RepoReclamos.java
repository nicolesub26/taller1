package taller.BD.Server;

import org.springframework.data.repository.CrudRepository;

public interface RepoReclamos extends CrudRepository<Reclamos,Integer> {
    
}
